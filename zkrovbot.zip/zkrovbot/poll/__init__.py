from poll.config import questions
from poll.anket import Anket
from poll.linked_list import get_question_node, sum_linked_list, LinkedList


question = qhead = get_question_node(questions)
